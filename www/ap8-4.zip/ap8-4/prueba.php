<?php
require_once "clases/Modelo.php";
$modelo = new Modelo();
$modelo->importar();
